
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import './App.css';
import { Header } from './components/Header';
import { TodoListComponent } from './components/TodoList';
import { CreateTodoComponent } from './components/CreateTodo';
import { EditTodoComponent } from './components/EditTodo';

function App() {
  return (
    <BrowserRouter>
      <div className='container'>
        <Header/>
        <Switch>
          <Route path="/" exact>
              <TodoListComponent/>
          </Route>
          <Route path="/create">
              <CreateTodoComponent/>
          </Route>
          <Route path="/edit/:id">
            <EditTodoComponent/>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
