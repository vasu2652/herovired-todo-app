import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Todo = props => (
    <tr>
        <td className={props.todo.todo_completed ? 'completed' : ''}>{props.todo.title}</td>
        <td className={props.todo.todo_completed ? 'completed' : ''}>{props.todo.description}</td>
        <td className={props.todo.todo_completed ? 'completed' : ''}>{props.todo.assigned}</td>
        <td className={props.todo.todo_completed ? 'completed' : ''}>{props.todo.priority}</td>
        <td className={props.todo.todo_completed ? 'completed' : ''}>{props.todo.status}</td>
        <td>
            <Link to={"/edit/" + props.todo._id}>Edit</Link>
        </td>
    </tr>
)
export const TodoListComponent = () => {
    const [todos, setTodos] = useState([]);
    useEffect(() => {
        axios.get('http://localhost:4000/todos').then(res => {
            setTodos(res.data)
        }).catch(err => console.log(err));
    }, [])
    return (
        <div>
            <h3>Todos List</h3>
            <table className="table table-striped" style={{ marginTop: 20 }}>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Assigned</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {todos.map(todo => <Todo todo={todo}/>)}
                </tbody>
            </table>
        </div>
    )
}