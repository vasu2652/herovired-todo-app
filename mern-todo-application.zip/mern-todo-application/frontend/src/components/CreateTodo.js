import axios from 'axios';
import React, { useState } from 'react';
export const CreateTodoComponent = () => {
    const [formData, setFormData] = useState({});
    const onSubmit = () => {
        axios.post('http://localhost:4000/create/todo', formData).then(res=>{
            console.log(res.data);
        });
        setFormData({
            title:"",
            description: "",
            assigned: "",
            status: "",
            priority:""
        });
    }
    return (
        <div style={{ marginTop: 20 }}>
            <h3>Create New Todo</h3>
            <div>
                <div className="form-group">
                    <label>Title: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.title}
                        onChange={(e)=>{
                            setFormData({
                                ...formData,
                                title: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <label>Description: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.description}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                description: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <label>Assigned: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.assigned}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                assigned: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <label>Status: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.status}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                status: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <div className="form-check form-check-inline">
                        <input className="form-check-input"
                            type="radio"
                            name="priorityOptions"
                            id="priorityLow"
                            value="low"
                            checked={formData.priority === 'low'}
                            onChange={(e) => {
                                setFormData({
                                    ...formData,
                                    priority: e.target.value
                                })
                            }}
                        />
                        <label className="form-check-label">Low</label>
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input"
                            type="radio"
                            name="priorityOptions"
                            id="priorityMedium"
                            value="medium"
                            checked={formData.priority === 'medium'}
                            onChange={(e) => {
                                setFormData({
                                    ...formData,
                                    priority: e.target.value
                                })
                            }}
                        />
                        <label className="form-check-label">Medium</label>
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input"
                            type="radio"
                            name="priorityOptions"
                            id="priorityHigh"
                            value="high"
                            checked={formData.priority === 'high'}
                            onChange={(e) => {
                                setFormData({
                                    ...formData,
                                    priority: e.target.value
                                })
                            }}
                        />
                        <label className="form-check-label">High</label>
                    </div>
                </div>
                <br />
                <div className="form-group">
                    <button type="submit" className="btn btn-primary" onClick={() => onSubmit()}>Submit</button>
                </div>
            </div>
        </div>
    )
}