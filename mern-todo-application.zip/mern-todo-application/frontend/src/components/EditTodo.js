import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
export const EditTodoComponent = () => {
    const [formData, setFormData] = useState({});
    const { id } = useParams();
    const history = useHistory();
    useEffect(()=>{
        axios.get('http://localhost:4000/todo/'+id).then(res=>{
            setFormData(res.data)
        })
    },[id])
    const onSubmit=()=>{
        axios.put('http://localhost:4000/update/todo/'+id, formData).then(res=>console.log(res.data));
        history.push('/');
    }
    return (
        <div style={{ marginTop: 20 }}>
            <h3>Create New Todo</h3>
            <div>
                <div className="form-group">
                    <label>Title: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.title}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                title: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <label>Description: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.description}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                description: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <label>Assigned: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.assigned}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                assigned: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <label>Status: </label>
                    <input type="text"
                        className="form-control"
                        value={formData.status}
                        onChange={(e) => {
                            setFormData({
                                ...formData,
                                status: e.target.value
                            })
                        }}
                    />
                </div>
                <div className="form-group">
                    <div className="form-check form-check-inline">
                        <input className="form-check-input"
                            type="radio"
                            name="priorityOptions"
                            id="priorityLow"
                            value="low"
                            checked={formData.priority === 'low'}
                            onChange={(e) => {
                                setFormData({
                                    ...formData,
                                    priority: e.target.value
                                })
                            }}
                        />
                        <label className="form-check-label">Low</label>
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input"
                            type="radio"
                            name="priorityOptions"
                            id="priorityMedium"
                            value="medium"
                            checked={formData.priority === 'medium'}
                            onChange={(e) => {
                                setFormData({
                                    ...formData,
                                    priority: e.target.value
                                })
                            }}
                        />
                        <label className="form-check-label">Medium</label>
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input"
                            type="radio"
                            name="priorityOptions"
                            id="priorityHigh"
                            value="high"
                            checked={formData.priority === 'high'}
                            onChange={(e) => {
                                setFormData({
                                    ...formData,
                                    priority: e.target.value
                                })
                            }}
                        />
                        <label className="form-check-label">High</label>
                    </div>
                </div>
                <br />
                <div className="form-group">
                    <button type="submit" className="btn btn-primary" onClick={() => onSubmit()}>Submit</button>
                </div>
            </div>
        </div>
    )
}