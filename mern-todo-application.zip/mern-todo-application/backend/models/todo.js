const mongoose = require('mongoose');
const Schema = mongoose.Schema;
//title, description, priority, status, responsible
const Todo = new Schema({
    title:{
        type: String
    },
    description:{
        type: String
    },
    priority:{
        type: String
    },
    status:{
        type: String
    },
    assigned:{
        type: String
    }
})

module.exports = mongoose.model('Todo', Todo);


