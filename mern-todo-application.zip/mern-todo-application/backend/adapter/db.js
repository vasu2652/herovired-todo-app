const mongoose = require('mongoose');

//creating a connection to database;
function connectToDataBase(){
    mongoose.connect('mongodb://localhost:27017/todo_application', { useNewUrlParser: true });
    const connection = mongoose.connection;
    connection.once('open', () => {
        console.log("A new connection has been opened to the database");
    });
    return connection;
}

module.exports = {
    connectToDataBase
}