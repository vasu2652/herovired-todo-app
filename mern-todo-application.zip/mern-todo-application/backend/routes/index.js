var express = require('express');
var router = express.Router();
const TodoModel = require('../models/todo');
/**
 * Create a todo
 * Update a todo
 * Read todo
 * Delete todo
 */

router.get('/todos', function (req, res) {
  TodoModel.find((err, data) => {
    if (err)
      console.log(err);
    else
      res.json(data);
  })
});

router.get('/todo/:id', function(req, res){
  const { id } = req.params;
  TodoModel.findById(id, (err, data) => {
    if (err)
      console.log(err);
    else
      res.json(data);
  })
})
//post it means it should create new data
router.post('/create/todo', function (req, res) {
  const todo = new TodoModel(req.body);
  todo.save().then(todo => {
    res.status(200).send("New Todo Added");
  }).catch(error => res.status(500).send("Internal error occured"))
});

//put=updating the data.
router.put('/update/todo/:id', function (req, res) {
  const { id } = req.params;
  TodoModel.findById(id, (err, todo) => {
    if (err)
      res.status(404).send("RECORD NOT FOUND");
    else {
      //optional chaining, nullish operator syntax

      todo.description = req.body?.description ?? todo.description;
      todo.title = req.body?.title ?? todo.title;
      todo.assigned = req.body?.assigned ?? todo.assigned;
      todo.status = req.body?.status ?? todo.status;
      todo.priority = req.body?.priority ?? todo.priority;

      todo.save().then(todo => {
        console.log("todo updated");
        res.send("todo updated")
      }).catch(err => {
        console.log("failed in updating");
        res.status(500).send("failed in updating")
      });
    }
  })
});

router.delete('/delete/todo', function (req, res) {

});


module.exports = router;
